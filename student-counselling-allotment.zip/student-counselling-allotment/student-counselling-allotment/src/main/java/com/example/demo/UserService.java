package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private StudentRepo userRepository;

    public void saveUser(StudentEntity user) {
        userRepository.save(user);
    }

    public StudentEntity findByUsername(String username) {
        return userRepository.findByName(username);
    }
}
