package com.example.demo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface StudentRepo extends CrudRepository<StudentEntity, Long> {
    Optional<StudentEntity> findByPhone(String phone);
    Optional<StudentEntity> findByEmail(String email);
	StudentEntity findByName(String username);
	
}
